# run_prod.py

import os
from waitress import serve
from app import create_app # Import the factory function

if __name__ == "__main__":
    # Call the factory to create the app instance
    app = create_app()

    # Get host and port from environment variables for more flexibility
    # Default to your values if they aren't set
    host = os.environ.get('APP_HOST', '127.0.0.1')
    port = int(os.environ.get('APP_PORT', 8015))

    print(f"INFO: Starting Waitress server at http://{host}:{port}")
    
    # Start the application using the Waitress server
    serve(app, host=host, port=port)